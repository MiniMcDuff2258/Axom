import { useEffect, useState } from "react";
import { useGetRandomAdvert, getGetRandomAdvertQueryKey } from "@workspace/api-client-react";
import { X } from "lucide-react";
import { useLocation } from "wouter";

export function AdvertPopup() {
  const [show, setShow] = useState(false);
  const [location] = useLocation();
  const { data: advert, refetch } = useGetRandomAdvert({
    query: {
      enabled: false,
      queryKey: getGetRandomAdvertQueryKey()
    }
  });

  useEffect(() => {
    // Show an ad periodically on navigation
    if (Math.random() < 0.3) {
      refetch().then(res => {
        if (res.data) setShow(true);
      });
    }
  }, [location, refetch]);

  if (!show || !advert) return null;

  return (
    <div className="fixed bottom-20 right-4 md:bottom-8 md:right-8 w-80 bg-card border border-primary/50 rounded-xl shadow-2xl z-50 overflow-hidden animate-in slide-in-from-bottom-4 fade-in duration-300">
      <div className="p-3 bg-primary/10 border-b border-primary/20 flex justify-between items-center">
        <span className="text-xs font-bold uppercase tracking-wider text-primary">Sponsored</span>
        <button onClick={() => setShow(false)} className="text-muted-foreground hover:text-foreground">
          <X className="w-4 h-4" />
        </button>
      </div>
      {advert.imageUrl && (
        <img src={advert.imageUrl} alt="" className="w-full h-32 object-cover" />
      )}
      <div className="p-4">
        <h4 className="font-bold text-lg mb-1 leading-tight">{advert.title}</h4>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{advert.content}</p>
        {advert.linkUrl && (
          <a 
            href={advert.linkUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block w-full py-2 text-center bg-primary text-primary-foreground rounded-md font-medium text-sm hover:brightness-110 transition-all"
          >
            Learn More
          </a>
        )}
      </div>
    </div>
  );
}
