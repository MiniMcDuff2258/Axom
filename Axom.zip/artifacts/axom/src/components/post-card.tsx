import { Heart, MessageCircle, Bookmark, AlertTriangle, ShieldCheck } from "lucide-react";
import { type Post, useLikePost, useBookmarkPost, getListPostsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

export function PostCard({ post }: { post: Post }) {
  const queryClient = useQueryClient();
  const likeMutation = useLikePost();
  const bookmarkMutation = useBookmarkPost();

  const handleLike = () => {
    likeMutation.mutate({ id: post.id, data: {} }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
      }
    });
  };

  const handleBookmark = () => {
    bookmarkMutation.mutate({ id: post.id, data: {} }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
      }
    });
  };

  return (
    <article className="bg-card border border-border rounded-xl p-5 shadow-sm transition-all hover:border-primary/30">
      <div className="flex items-start gap-3 mb-3">
        <div className="w-10 h-10 rounded-full bg-sidebar border border-border overflow-hidden">
          {post.user.profileImage && <img src={post.user.profileImage} alt="" className="w-full h-full object-cover"/>}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-bold truncate">{post.user.displayName}</span>
            {post.user.verified && <ShieldCheck className="w-4 h-4 text-blue-500" />}
            <span className="text-sm text-muted-foreground truncate">@{post.user.username}</span>
            <span className="text-xs text-muted-foreground ml-auto">
              {new Date(post.createdAt).toLocaleDateString()}
            </span>
          </div>
          {post.user.role !== 'default' && (
            <span className="inline-block px-2 py-0.5 mt-1 rounded text-[10px] font-bold uppercase tracking-wider bg-primary/10 text-primary border border-primary/20">
              {post.user.role}
            </span>
          )}
          {post.ageRating !== '5+' && (
             <span className="inline-block px-2 py-0.5 mt-1 ml-2 rounded text-[10px] font-bold uppercase tracking-wider bg-destructive/10 text-destructive border border-destructive/20">
             {post.ageRating}
           </span>
          )}
        </div>
      </div>
      
      <p className="text-foreground/90 whitespace-pre-wrap leading-relaxed">{post.content}</p>
      
      {post.mediaUrls && post.mediaUrls.length > 0 && (
        <div className="mt-4 rounded-lg overflow-hidden border border-border bg-sidebar">
          {post.mediaType === 'video' ? (
            <video src={post.mediaUrls[0]} controls className="w-full max-h-96 object-cover" />
          ) : (
            <img src={post.mediaUrls[0]} alt="" className="w-full max-h-96 object-cover" />
          )}
        </div>
      )}

      <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50 text-muted-foreground">
        <button 
          onClick={handleLike}
          disabled={likeMutation.isPending}
          className={cn("flex items-center gap-1.5 transition-colors group", post.liked ? "text-primary" : "hover:text-primary")}
        >
          <Heart className={cn("w-5 h-5 transition-transform group-hover:scale-110", post.liked && "fill-current")} />
          <span className="text-sm font-medium">{post.likesCount}</span>
        </button>
        <button className="flex items-center gap-1.5 hover:text-primary transition-colors group">
          <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-sm font-medium">{post.commentsCount}</span>
        </button>
        <button 
          onClick={handleBookmark}
          disabled={bookmarkMutation.isPending}
          className={cn("flex items-center gap-1.5 transition-colors group", post.bookmarked ? "text-primary" : "hover:text-primary")}
        >
          <Bookmark className={cn("w-5 h-5 transition-transform group-hover:scale-110", post.bookmarked && "fill-current")} />
          <span className="text-sm font-medium">{post.bookmarksCount}</span>
        </button>
        <button className="flex items-center gap-1.5 hover:text-destructive transition-colors opacity-0 group-hover:opacity-100">
          <AlertTriangle className="w-5 h-5" />
        </button>
      </div>
    </article>
  );
}
