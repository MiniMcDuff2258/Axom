import { useListClips, getListClipsQueryKey, useLikePost, useBookmarkPost } from "@workspace/api-client-react";
import { Heart, MessageCircle, Bookmark, AlertTriangle, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";

export default function Clips() {
  const { data: clips, isLoading } = useListClips({ query: { queryKey: getListClipsQueryKey() } });
  const queryClient = useQueryClient();
  const likeMutation = useLikePost();
  const bookmarkMutation = useBookmarkPost();

  if (isLoading) {
    return <div className="min-h-[100dvh] flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  return (
    <div className="h-[calc(100dvh-64px)] md:h-[100dvh] w-full bg-black snap-y snap-mandatory overflow-y-auto scroll-smooth">
      {clips?.map(clip => (
        <div key={clip.id} className="h-full w-full snap-start snap-always relative flex justify-center items-center bg-black border-b border-white/10 md:border-none">
          <div className="absolute inset-0 max-w-lg mx-auto w-full h-full relative">
            {clip.mediaUrls?.[0] && (
              <video 
                src={clip.mediaUrls[0]} 
                className="w-full h-full object-cover"
                autoPlay 
                loop 
                muted 
                playsInline 
              />
            )}
            
            {/* Overlay Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end gap-4 pb-20 md:pb-8">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-10 h-10 rounded-full bg-sidebar border border-white/20 overflow-hidden flex-shrink-0">
                    {clip.user.profileImage && <img src={clip.user.profileImage} alt="" className="w-full h-full object-cover"/>}
                  </div>
                  <div>
                    <div className="flex items-center gap-1 text-white">
                      <span className="font-bold text-sm">{clip.user.displayName}</span>
                      {clip.user.verified && <ShieldCheck className="w-4 h-4 text-blue-400" />}
                    </div>
                    <span className="text-xs text-white/60">@{clip.user.username}</span>
                  </div>
                </div>
                <p className="text-white text-sm line-clamp-3">{clip.content}</p>
              </div>

              {/* Actions Side */}
              <div className="flex flex-col items-center gap-6 mb-4 shrink-0">
                <button 
                  onClick={() => likeMutation.mutate({ id: clip.id, data: {} }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListClipsQueryKey() }) })}
                  className="flex flex-col items-center gap-1 group text-white drop-shadow-md"
                >
                  <div className="w-12 h-12 bg-black/20 backdrop-blur-sm rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
                    <Heart className={cn("w-6 h-6", clip.liked && "fill-destructive text-destructive")} />
                  </div>
                  <span className="text-xs font-bold">{clip.likesCount}</span>
                </button>

                <button className="flex flex-col items-center gap-1 group text-white drop-shadow-md">
                  <div className="w-12 h-12 bg-black/20 backdrop-blur-sm rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold">{clip.commentsCount}</span>
                </button>

                <button 
                  onClick={() => bookmarkMutation.mutate({ id: clip.id, data: {} }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListClipsQueryKey() }) })}
                  className="flex flex-col items-center gap-1 group text-white drop-shadow-md"
                >
                  <div className="w-12 h-12 bg-black/20 backdrop-blur-sm rounded-full flex items-center justify-center transition-transform group-hover:scale-110">
                    <Bookmark className={cn("w-6 h-6", clip.bookmarked && "fill-white")} />
                  </div>
                  <span className="text-xs font-bold">{clip.bookmarksCount}</span>
                </button>

                <button className="flex flex-col items-center gap-1 group text-white/60 drop-shadow-md mt-4">
                  <AlertTriangle className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
      {clips?.length === 0 && (
        <div className="h-full flex items-center justify-center text-muted-foreground">
          No clips found.
        </div>
      )}
    </div>
  );
}
