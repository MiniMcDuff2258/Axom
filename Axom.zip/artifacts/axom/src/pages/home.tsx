import { useListPosts, getListPostsQueryKey, useCreatePost } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { PostCard } from "@/components/post-card";
import { AdvertPopup } from "@/components/advert-popup";

export default function Home() {
  const { data: posts, isLoading } = useListPosts({ query: { queryKey: getListPostsQueryKey() } });
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createPostMutation = useCreatePost();

  const [content, setContent] = useState("");

  const handleCreatePost = () => {
    if (!content.trim()) return;
    createPostMutation.mutate({ data: { content } }, {
      onSuccess: () => {
        setContent("");
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey() });
        toast({ title: "Post created!" });
      },
      onError: (err: any) => {
        toast({ title: "Failed to create post", description: err.error, variant: "destructive" });
      }
    });
  };

  if (isLoading) {
    return <div className="p-8 flex justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  return (
    <div className="max-w-2xl mx-auto w-full p-4 md:p-8">
      <AdvertPopup />
      <header className="mb-8">
        <h1 className="text-2xl font-bold">Home Feed</h1>
        <p className="text-muted-foreground">Welcome back, {user?.displayName}</p>
      </header>

      {user?.role !== 'default' && (
        <div className="bg-card border border-border p-4 rounded-xl mb-8 shadow-sm">
          <div className="flex gap-4">
            <div className="w-10 h-10 rounded-full bg-sidebar border border-border flex-shrink-0 overflow-hidden">
              {user?.profileImage && <img src={user.profileImage} alt="" className="w-full h-full object-cover" />}
            </div>
            <div className="flex-1">
              <Textarea 
                placeholder="What's on your mind?" 
                className="w-full bg-transparent border-none outline-none focus-visible:ring-0 text-lg placeholder:text-muted-foreground mb-4 min-h-[100px] resize-none"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
              <div className="flex justify-between items-center border-t border-border/50 pt-3">
                <div className="flex gap-2 text-primary">
                </div>
                <Button 
                  className="font-bold px-6 rounded-full" 
                  onClick={handleCreatePost}
                  disabled={createPostMutation.isPending || !content.trim()}
                >
                  {createPostMutation.isPending ? "Posting..." : "Post"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-6">
        {posts?.map(post => (
          <PostCard key={post.id} post={post} />
        ))}
        {posts?.length === 0 && (
          <div className="text-center p-8 text-muted-foreground border border-dashed border-border rounded-xl">
            No posts found.
          </div>
        )}
      </div>
    </div>
  );
}
