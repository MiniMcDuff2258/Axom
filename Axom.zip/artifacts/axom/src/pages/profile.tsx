import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { ShieldCheck, LogOut, Settings, Image as ImageIcon } from "lucide-react";
import { useLogout, useUpdateUser } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function Profile() {
  const { user, logout } = useAuth();
  const logoutMutation = useLogout();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation("/login");
    logoutMutation.mutate(undefined);
  };

  if (!user) return null;

  const statusColors = {
    online: "bg-green-500",
    offline: "bg-gray-500",
    timeout: "bg-yellow-500",
    kick: "bg-red-500",
    ban: "bg-red-700"
  };

  return (
    <div className="max-w-4xl mx-auto w-full pb-8">
      {/* Banner */}
      <div className="h-48 md:h-64 w-full bg-sidebar border-b border-border relative overflow-hidden group">
        {user.bannerImage ? (
          <img src={user.bannerImage} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-background" />
        )}
        <Button variant="secondary" size="sm" className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity gap-2">
          <ImageIcon className="w-4 h-4" /> Edit Banner
        </Button>
      </div>

      <div className="px-4 md:px-8 relative">
        {/* Avatar */}
        <div className="flex justify-between items-end -mt-16 md:-mt-20 mb-4">
          <div className="relative group">
            <div className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-background bg-sidebar overflow-hidden shadow-xl">
              {user.profileImage ? (
                <img src={user.profileImage} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-primary/10 text-primary text-4xl font-bold uppercase">
                  {user.displayName.charAt(0)}
                </div>
              )}
            </div>
            <div className={cn("absolute bottom-2 right-2 w-6 h-6 rounded-full border-4 border-background", statusColors[user.status as keyof typeof statusColors] || statusColors.offline)} />
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2"><Settings className="w-4 h-4" /> Edit Profile</Button>
            <Button variant="destructive" className="gap-2" onClick={handleLogout}><LogOut className="w-4 h-4" /> Logout</Button>
          </div>
        </div>

        {/* Info */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-3xl font-black">{user.displayName}</h1>
            {user.verified && <ShieldCheck className="w-6 h-6 text-blue-500" />}
          </div>
          <p className="text-muted-foreground font-medium mb-3">@{user.username}</p>
          
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-card border border-border">
              Age: {user.age} ({user.ageGroup})
            </span>
            {user.role !== 'default' && (
              <span className="px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-primary/20 text-primary border border-primary/30 shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                {user.role.replace('_', ' ')}
              </span>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 border-y border-border py-6 mb-8">
          <div className="text-center">
            <span className="block text-2xl font-black text-primary">0</span>
            <span className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Posts</span>
          </div>
          <div className="text-center border-x border-border">
            <span className="block text-2xl font-black text-primary">0</span>
            <span className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Followers</span>
          </div>
          <div className="text-center">
            <span className="block text-2xl font-black text-primary">0</span>
            <span className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Following</span>
          </div>
        </div>
      </div>
    </div>
  );
}
