import { useListChannels, getListChannelsQueryKey, useListMessages, getListMessagesQueryKey, useSendMessage } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { useState, useRef, useEffect } from "react";
import { Send, Users, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Messages() {
  const { user } = useAuth();
  const { data: channels } = useListChannels({ query: { queryKey: getListChannelsQueryKey() } });
  const [activeChannelId, setActiveChannelId] = useState<number | null>(null);

  const { data: messages, refetch: refetchMessages } = useListMessages(activeChannelId || 0, {
    query: {
      enabled: !!activeChannelId,
      queryKey: getListMessagesQueryKey(activeChannelId || 0),
      refetchInterval: 5000
    }
  });

  const sendMessageMutation = useSendMessage();
  const [content, setContent] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !activeChannelId) return;
    
    sendMessageMutation.mutate({ id: activeChannelId, data: { content } }, {
      onSuccess: () => {
        setContent("");
        refetchMessages();
      }
    });
  };

  return (
    <div className="flex h-[calc(100dvh-64px)] md:h-[100dvh]">
      {/* Channels Sidebar */}
      <div className={cn(
        "w-full md:w-80 border-r border-border bg-card flex flex-col",
        activeChannelId !== null ? "hidden md:flex" : "flex"
      )}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-bold text-lg">Messages</h2>
          <Button variant="ghost" size="icon" className="rounded-full w-8 h-8"><Users className="w-4 h-4" /></Button>
        </div>
        <div className="flex-1 overflow-y-auto">
          {channels?.map(channel => {
            const otherParticipants = channel.participants.filter(p => p.id !== user?.id);
            const name = channel.name || otherParticipants.map(p => p.displayName).join(", ");
            return (
              <button
                key={channel.id}
                onClick={() => setActiveChannelId(channel.id)}
                className={cn(
                  "w-full p-4 flex items-center gap-3 hover:bg-sidebar-accent transition-colors text-left border-b border-border/50",
                  activeChannelId === channel.id && "bg-sidebar-accent"
                )}
              >
                <div className="w-10 h-10 rounded-full bg-sidebar border border-border flex items-center justify-center overflow-hidden flex-shrink-0">
                  {otherParticipants[0]?.profileImage ? (
                     <img src={otherParticipants[0].profileImage} alt="" className="w-full h-full object-cover" />
                  ) : channel.type === 'support' ? (
                    <ShieldAlert className="w-5 h-5 text-destructive" />
                  ) : (
                    <Users className="w-5 h-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-bold truncate text-sm">{name}</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{channel.lastMessage || "No messages yet"}</p>
                </div>
              </button>
            )
          })}
        </div>
      </div>

      {/* Message Area */}
      <div className={cn(
        "flex-1 flex flex-col bg-background relative",
        activeChannelId === null ? "hidden md:flex" : "flex"
      )}>
        {activeChannelId ? (
          <>
            <div className="p-4 border-b border-border flex items-center gap-3 bg-card sticky top-0 z-10">
              <button className="md:hidden text-muted-foreground p-2 -ml-2" onClick={() => setActiveChannelId(null)}>
                ← Back
              </button>
              <h3 className="font-bold">Chat</h3>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages?.map(msg => {
                const isMine = msg.userId === user?.id;
                return (
                  <div key={msg.id} className={cn("flex flex-col max-w-[75%]", isMine ? "ml-auto items-end" : "mr-auto items-start")}>
                    {!isMine && <span className="text-xs text-muted-foreground ml-1 mb-1">{msg.user.displayName}</span>}
                    <div className={cn(
                      "px-4 py-2 rounded-2xl",
                      isMine ? "bg-primary text-primary-foreground rounded-tr-sm" : "bg-card border border-border rounded-tl-sm"
                    )}>
                      {msg.content}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSend} className="p-4 bg-card border-t border-border flex gap-2">
              <Input 
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 bg-background"
              />
              <Button type="submit" size="icon" disabled={!content.trim() || sendMessageMutation.isPending}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground flex-col gap-4">
            <MessageSquare className="w-12 h-12 opacity-20" />
            <p>Select a conversation or start a new one</p>
          </div>
        )}
      </div>
    </div>
  );
}

import { MessageSquare } from "lucide-react";
