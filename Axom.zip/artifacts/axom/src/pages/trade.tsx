import { useState } from "react";
import { useListTradeListings, getListTradeListingsQueryKey, useCreateTradeListing } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Search, Plus, ShieldCheck, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const createListingSchema = z.object({
  title: z.string().min(3),
  description: z.string().min(10),
  price: z.string().min(1),
  category: z.string().min(1),
});

export default function Trade() {
  const [search, setSearch] = useState("");
  const { data: listings, isLoading } = useListTradeListings({ query: { queryKey: getListTradeListingsQueryKey({ search }) } });
  const { user } = useAuth();
  
  const canCreate = user && ['pro', 'creator_pro', 'staff', 'admin', 'owner'].includes(user.role);

  if (isLoading) {
    return <div className="min-h-[100dvh] flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  return (
    <div className="max-w-6xl mx-auto w-full p-4 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-black tracking-tighter">Trade & Exchange</h1>
          <p className="text-muted-foreground mt-1">Discover, buy, and sell within the community.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search listings..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 bg-card border-border"
            />
          </div>
          {canCreate && (
            <CreateListingDialog />
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listings?.map(listing => (
          <div key={listing.id} className="bg-card border border-border rounded-xl overflow-hidden shadow-lg group hover:border-primary/50 transition-colors">
            <div className="aspect-[4/3] bg-sidebar relative overflow-hidden border-b border-border">
              {listing.imageUrl ? (
                <img src={listing.imageUrl} alt={listing.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  <Tag className="w-12 h-12 opacity-20" />
                </div>
              )}
              <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md border border-white/10 px-2 py-1 rounded text-xs font-bold text-white flex items-center gap-1.5">
                {listing.category}
              </div>
              <div className="absolute bottom-3 right-3 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-black shadow-lg">
                ${listing.price}
              </div>
            </div>
            <div className="p-5">
              <h3 className="font-bold text-lg mb-2 line-clamp-1">{listing.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2 mb-4 h-10">{listing.description}</p>
              
              <div className="flex items-center gap-2 pt-4 border-t border-border/50">
                <div className="w-8 h-8 rounded-full bg-sidebar overflow-hidden border border-border">
                  {listing.user.profileImage && <img src={listing.user.profileImage} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-medium text-sm truncate">{listing.user.displayName}</span>
                    {listing.user.verified && <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />}
                  </div>
                  {listing.user.role !== 'default' && (
                    <span className="text-[10px] font-bold text-primary uppercase">{listing.user.role}</span>
                  )}
                </div>
                <Button variant="outline" size="sm" className="text-xs shrink-0">View</Button>
              </div>
            </div>
          </div>
        ))}
        {listings?.length === 0 && (
          <div className="col-span-full py-12 text-center text-muted-foreground border border-dashed border-border rounded-xl">
            No listings found matching your search.
          </div>
        )}
      </div>
    </div>
  );
}

function CreateListingDialog() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createMutation = useCreateTradeListing();

  const form = useForm<z.infer<typeof createListingSchema>>({
    resolver: zodResolver(createListingSchema),
    defaultValues: { title: "", description: "", price: "", category: "" },
  });

  const onSubmit = (values: z.infer<typeof createListingSchema>) => {
    createMutation.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Listing created!" });
        setOpen(false);
        form.reset();
        queryClient.invalidateQueries({ queryKey: getListTradeListingsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Failed to create", description: err.error, variant: "destructive" });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 font-bold"><Plus className="w-4 h-4" /> Create</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create Trade Listing</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="title" render={({ field }) => (
              <FormItem><FormLabel>Title</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="price" render={({ field }) => (
              <FormItem><FormLabel>Price</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <FormField control={form.control} name="category" render={({ field }) => (
              <FormItem>
                <FormLabel>Category</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl><SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger></FormControl>
                  <SelectContent>
                    <SelectItem value="digital">Digital Assets</SelectItem>
                    <SelectItem value="physical">Physical Goods</SelectItem>
                    <SelectItem value="services">Services</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea {...field} /></FormControl><FormMessage /></FormItem>
            )} />
            <Button type="submit" className="w-full" disabled={createMutation.isPending}>
              {createMutation.isPending ? "Creating..." : "Create Listing"}
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
