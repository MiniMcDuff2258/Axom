import { createContext, useContext, useCallback, useEffect, useState } from "react";
import { useGetMe } from "@workspace/api-client-react";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import type { User } from "@workspace/api-client-react";

const TOKEN_KEY = "axom_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

setAuthTokenGetter(() => getToken());

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  refetch: () => void;
  login: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  refetch: () => {},
  login: () => {},
  logout: () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [hasToken, setHasToken] = useState(!!getToken());

  const { data: user, isLoading, refetch } = useGetMe({
    query: {
      retry: false,
      enabled: hasToken,
    }
  });

  const login = useCallback((token: string) => {
    setToken(token);
    setHasToken(true);
    refetch();
  }, [refetch]);

  const logout = useCallback(() => {
    clearToken();
    setHasToken(false);
  }, []);

  return (
    <AuthContext.Provider value={{
      user: hasToken ? (user ?? null) : null,
      isLoading: hasToken ? isLoading : false,
      refetch,
      login,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
