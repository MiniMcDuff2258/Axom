import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const JWT_SECRET = process.env.SESSION_SECRET || "axom-secret-key";

export function generateToken(userId: number): string {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "7d" });
}

export function verifyToken(token: string): { userId: number } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as { userId: number };
  } catch {
    return null;
  }
}

export interface AuthRequest extends Request {
  user?: {
    id: number;
    username: string;
    displayName: string;
    email: string;
    dob: string;
    age: number;
    ageGroup: string;
    role: string;
    status: string;
    profileImage: string | null;
    bannerImage: string | null;
    verified: boolean;
    createdAt: Date;
    passwordHash: string;
  };
}

export async function authMiddleware(req: AuthRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);
  if (!payload) {
    res.status(401).json({ error: "Invalid token" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, payload.userId));
  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }

  if (user.status === "ban") {
    res.status(403).json({ error: "Account banned" });
    return;
  }

  req.user = user;
  next();
}

export function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    next();
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);
  if (!payload) {
    next();
    return;
  }

  db.select().from(usersTable).where(eq(usersTable.id, payload.userId)).then(([user]) => {
    if (user && user.status !== "ban") {
      req.user = user;
    }
    next();
  }).catch(() => next());
}

export function calculateAge(dob: string): number {
  const birth = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

export function getAgeGroup(age: number): string {
  if (age >= 18) return "18+";
  if (age >= 15) return "15+";
  if (age >= 10) return "10+";
  return "5+";
}

export function ageGroupValue(group: string): number {
  switch (group) {
    case "18+": return 18;
    case "15+": return 15;
    case "10+": return 10;
    default: return 5;
  }
}

const SUPPORT_ROLES = ["support", "moderator", "staff", "admin", "owner"];
const TRADE_ROLES = ["pro", "creator_pro", "staff", "admin", "owner"];

export function isSupportRole(role: string): boolean {
  return SUPPORT_ROLES.includes(role);
}

export function canCreatePost(role: string): boolean {
  return role !== "default";
}

export function canCreateTradeListing(role: string): boolean {
  return TRADE_ROLES.includes(role);
}

export function canComment(ageGroup: string): boolean {
  return ageGroupValue(ageGroup) >= 10;
}

export function canPostContent(ageGroup: string): boolean {
  return ageGroupValue(ageGroup) >= 15;
}

export function serializeUser(user: any) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    email: user.email,
    dob: user.dob,
    age: user.age,
    ageGroup: user.ageGroup,
    role: user.role,
    status: user.status,
    profileImage: user.profileImage,
    bannerImage: user.bannerImage,
    verified: user.verified,
    createdAt: user.createdAt instanceof Date ? user.createdAt.toISOString() : user.createdAt,
  };
}
