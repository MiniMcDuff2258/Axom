import { Router, type IRouter } from "express";
import { db, usersTable, postsTable, likesTable, bookmarksTable, commentsTable, reportsTable } from "@workspace/db";
import { eq, desc, and, sql, lte, count, inArray } from "drizzle-orm";
import { CreatePostBody, CreateCommentBody, ReportPostBody } from "@workspace/api-zod";
import { authMiddleware, optionalAuth, serializeUser, canCreatePost, canComment, ageGroupValue, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

async function enrichPost(post: any, userId?: number) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, post.userId));
  const [likesResult] = await db.select({ count: count() }).from(likesTable).where(eq(likesTable.postId, post.id));
  const [commentsResult] = await db.select({ count: count() }).from(commentsTable).where(eq(commentsTable.postId, post.id));
  const [bookmarksResult] = await db.select({ count: count() }).from(bookmarksTable).where(eq(bookmarksTable.postId, post.id));

  let liked = false;
  let bookmarked = false;
  if (userId) {
    const [likeRow] = await db.select().from(likesTable).where(and(eq(likesTable.postId, post.id), eq(likesTable.userId, userId)));
    liked = !!likeRow;
    const [bookmarkRow] = await db.select().from(bookmarksTable).where(and(eq(bookmarksTable.postId, post.id), eq(bookmarksTable.userId, userId)));
    bookmarked = !!bookmarkRow;
  }

  return {
    id: post.id,
    userId: post.userId,
    content: post.content,
    mediaUrls: post.mediaUrls || [],
    mediaType: post.mediaType,
    ageRating: post.ageRating,
    likesCount: likesResult?.count || 0,
    commentsCount: commentsResult?.count || 0,
    bookmarksCount: bookmarksResult?.count || 0,
    liked,
    bookmarked,
    createdAt: post.createdAt instanceof Date ? post.createdAt.toISOString() : post.createdAt,
    user: user ? serializeUser(user) : null,
  };
}

router.get("/posts", optionalAuth as any, async (req: AuthRequest, res): Promise<void> => {
  const limit = parseInt(req.query.limit as string) || 20;
  const offset = parseInt(req.query.offset as string) || 0;

  const userAgeValue = req.user ? ageGroupValue(req.user.ageGroup) : 5;
  const allowedRatings = ["5+"];
  if (userAgeValue >= 10) allowedRatings.push("10+");
  if (userAgeValue >= 15) allowedRatings.push("15+");
  if (userAgeValue >= 18) allowedRatings.push("18+");

  const posts = await db.select().from(postsTable)
    .where(inArray(postsTable.ageRating, allowedRatings))
    .orderBy(desc(postsTable.createdAt))
    .limit(limit)
    .offset(offset);

  const enriched = await Promise.all(posts.map(p => enrichPost(p, req.user?.id)));
  res.json(enriched);
});

router.post("/posts", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!canCreatePost(req.user!.role)) {
    res.status(403).json({ error: "Only users with a non-default role can create posts" });
    return;
  }

  if (ageGroupValue(req.user!.ageGroup) < 15) {
    res.status(403).json({ error: "Must be 15+ to post content" });
    return;
  }

  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [post] = await db.insert(postsTable).values({
    userId: req.user!.id,
    content: parsed.data.content,
    mediaUrls: parsed.data.mediaUrls || [],
    mediaType: parsed.data.mediaType ?? null,
    ageRating: parsed.data.ageRating || "5+",
  }).returning();

  const enriched = await enrichPost(post, req.user!.id);
  res.status(201).json(enriched);
});

router.get("/posts/:id", optionalAuth as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const userAgeValue = req.user ? ageGroupValue(req.user.ageGroup) : 5;
  const postAgeValue = ageGroupValue(post.ageRating);
  if (postAgeValue > userAgeValue) {
    res.status(403).json({ error: "Age-restricted content" });
    return;
  }

  const enriched = await enrichPost(post, req.user?.id);
  res.json(enriched);
});

router.delete("/posts/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, id));
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  if (post.userId !== req.user!.id && !["moderator", "staff", "admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(postsTable).where(eq(postsTable.id, id));
  res.sendStatus(204);
});

router.post("/posts/:id/like", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (ageGroupValue(req.user!.ageGroup) < 10) {
    res.status(403).json({ error: "Must be 10+ to like posts" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [existing] = await db.select().from(likesTable).where(
    and(eq(likesTable.postId, id), eq(likesTable.userId, req.user!.id))
  );

  if (existing) {
    await db.delete(likesTable).where(eq(likesTable.id, existing.id));
  } else {
    await db.insert(likesTable).values({ postId: id, userId: req.user!.id });
  }

  const [result] = await db.select({ count: count() }).from(likesTable).where(eq(likesTable.postId, id));
  res.json({ liked: !existing, likesCount: result?.count || 0 });
});

router.post("/posts/:id/bookmark", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [existing] = await db.select().from(bookmarksTable).where(
    and(eq(bookmarksTable.postId, id), eq(bookmarksTable.userId, req.user!.id))
  );

  if (existing) {
    await db.delete(bookmarksTable).where(eq(bookmarksTable.id, existing.id));
  } else {
    await db.insert(bookmarksTable).values({ postId: id, userId: req.user!.id });
  }

  const [result] = await db.select({ count: count() }).from(bookmarksTable).where(eq(bookmarksTable.postId, id));
  res.json({ bookmarked: !existing, bookmarksCount: result?.count || 0 });
});

router.get("/posts/:id/comments", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const comments = await db.select().from(commentsTable)
    .where(eq(commentsTable.postId, id))
    .orderBy(desc(commentsTable.createdAt));

  const enriched = await Promise.all(comments.map(async (c) => {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, c.userId));
    return {
      id: c.id,
      postId: c.postId,
      userId: c.userId,
      content: c.content,
      createdAt: c.createdAt instanceof Date ? c.createdAt.toISOString() : c.createdAt,
      user: user ? serializeUser(user) : null,
    };
  }));

  res.json(enriched);
});

router.post("/posts/:id/comments", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!canComment(req.user!.ageGroup)) {
    res.status(403).json({ error: "Must be 10+ to comment" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const parsed = CreateCommentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [comment] = await db.insert(commentsTable).values({
    postId: id,
    userId: req.user!.id,
    content: parsed.data.content,
  }).returning();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  res.status(201).json({
    id: comment.id,
    postId: comment.postId,
    userId: comment.userId,
    content: comment.content,
    createdAt: comment.createdAt instanceof Date ? comment.createdAt.toISOString() : comment.createdAt,
    user: user ? serializeUser(user) : null,
  });
});

router.post("/posts/:id/report", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const parsed = ReportPostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await db.insert(reportsTable).values({
    postId: id,
    userId: req.user!.id,
    reason: parsed.data.reason,
  });

  res.status(201).json({ message: "Post reported" });
});

router.get("/clips", optionalAuth as any, async (req: AuthRequest, res): Promise<void> => {
  const limit = parseInt(req.query.limit as string) || 20;
  const offset = parseInt(req.query.offset as string) || 0;

  const userAgeValue = req.user ? ageGroupValue(req.user.ageGroup) : 5;
  const allowedRatings = ["5+"];
  if (userAgeValue >= 10) allowedRatings.push("10+");
  if (userAgeValue >= 15) allowedRatings.push("15+");
  if (userAgeValue >= 18) allowedRatings.push("18+");

  const posts = await db.select().from(postsTable)
    .where(and(
      eq(postsTable.mediaType, "video"),
      inArray(postsTable.ageRating, allowedRatings)
    ))
    .orderBy(desc(postsTable.createdAt))
    .limit(limit)
    .offset(offset);

  const enriched = await Promise.all(posts.map(p => enrichPost(p, req.user?.id)));
  res.json(enriched);
});

router.get("/bookmarks", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const userBookmarks = await db.select().from(bookmarksTable)
    .where(eq(bookmarksTable.userId, req.user!.id))
    .orderBy(desc(bookmarksTable.createdAt));

  const posts = await Promise.all(userBookmarks.map(async (b) => {
    const [post] = await db.select().from(postsTable).where(eq(postsTable.id, b.postId));
    if (!post) return null;
    return enrichPost(post, req.user!.id);
  }));

  res.json(posts.filter(Boolean));
});

router.get("/feed/summary", optionalAuth as any, async (req: AuthRequest, res): Promise<void> => {
  const [postsCount] = await db.select({ count: count() }).from(postsTable);
  const [clipsCount] = await db.select({ count: count() }).from(postsTable).where(eq(postsTable.mediaType, "video"));
  const [usersCount] = await db.select({ count: count() }).from(usersTable);

  res.json({
    totalPosts: postsCount?.count || 0,
    totalClips: clipsCount?.count || 0,
    totalUsers: usersCount?.count || 0,
    trendingTags: [],
  });
});

export default router;
