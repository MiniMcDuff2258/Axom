import { Router, type IRouter } from "express";
import bcrypt from "bcrypt";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SignupBody, LoginBody } from "@workspace/api-zod";
import { generateToken, calculateAge, getAgeGroup, authMiddleware, serializeUser, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

router.post("/auth/signup", async (req, res): Promise<void> => {
  const parsed = SignupBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, displayName, email, password, dob } = parsed.data;

  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing.length > 0) {
    res.status(400).json({ error: "Email already registered" });
    return;
  }

  const existingUsername = await db.select().from(usersTable).where(eq(usersTable.username, username));
  if (existingUsername.length > 0) {
    res.status(400).json({ error: "Username already taken" });
    return;
  }

  const age = calculateAge(dob);
  if (age < 5) {
    res.status(400).json({ error: "Must be at least 5 years old" });
    return;
  }

  const ageGroup = getAgeGroup(age);
  const passwordHash = await bcrypt.hash(password, 10);

  const [user] = await db.insert(usersTable).values({
    username,
    displayName,
    email,
    passwordHash,
    dob,
    age,
    ageGroup,
  }).returning();

  const token = generateToken(user.id);
  res.status(201).json({ user: serializeUser(user), token });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  if (user.status === "ban") {
    res.status(403).json({ error: "Account banned" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  await db.update(usersTable).set({ status: "online" }).where(eq(usersTable.id, user.id));

  const token = generateToken(user.id);
  res.status(200).json({ user: serializeUser({ ...user, status: "online" }), token });
});

router.post("/auth/logout", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (req.user) {
    await db.update(usersTable).set({ status: "offline" }).where(eq(usersTable.id, req.user.id));
  }
  res.json({ message: "Logged out" });
});

router.get("/auth/me", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  res.json(serializeUser(req.user!));
});

export default router;
