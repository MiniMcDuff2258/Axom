import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import { GetUserParams, UpdateUserBody } from "@workspace/api-zod";
import { authMiddleware, serializeUser, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

router.get("/users/search", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const q = req.query.q as string;
  if (!q) {
    res.json([]);
    return;
  }

  const users = await db.select().from(usersTable).where(
    or(
      ilike(usersTable.username, `%${q}%`),
      ilike(usersTable.displayName, `%${q}%`)
    )
  ).limit(20);

  res.json(users.map(serializeUser));
});

router.get("/users/:id", async (req, res): Promise<void> => {
  const params = GetUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(serializeUser(user));
});

router.patch("/users/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  if (req.user!.id !== id && !["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const parsed = UpdateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: any = {};
  if (parsed.data.displayName) updateData.displayName = parsed.data.displayName;
  if (parsed.data.profileImage) updateData.profileImage = parsed.data.profileImage;
  if (parsed.data.bannerImage) updateData.bannerImage = parsed.data.bannerImage;

  const [user] = await db.update(usersTable).set(updateData).where(eq(usersTable.id, id)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(serializeUser(user));
});

router.patch("/users/:id/role", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Only admins can change roles" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { role } = req.body;

  const validRoles = ["default", "creator", "creator_pro", "pro", "advert", "support", "moderator", "staff", "admin", "owner"];
  if (!validRoles.includes(role)) {
    res.status(400).json({ error: "Invalid role" });
    return;
  }

  const [user] = await db.update(usersTable).set({ role }).where(eq(usersTable.id, id)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(serializeUser(user));
});

router.patch("/users/:id/status", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!["moderator", "staff", "admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Insufficient permissions" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  const { status } = req.body;

  const validStatuses = ["online", "offline", "timeout", "kick", "ban"];
  if (!validStatuses.includes(status)) {
    res.status(400).json({ error: "Invalid status" });
    return;
  }

  const [user] = await db.update(usersTable).set({ status }).where(eq(usersTable.id, id)).returning();
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(serializeUser(user));
});

router.patch("/users/:id/verify", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Only admins can verify users" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [user] = await db.update(usersTable).set({ verified: !existing.verified }).where(eq(usersTable.id, id)).returning();
  res.json(serializeUser(user));
});

export default router;
