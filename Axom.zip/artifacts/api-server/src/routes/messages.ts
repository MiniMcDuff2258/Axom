import { Router, type IRouter } from "express";
import { db, usersTable, channelsTable, channelParticipantsTable, messagesTable } from "@workspace/db";
import { eq, desc, and, inArray } from "drizzle-orm";
import { CreateChannelBody, SendMessageBody } from "@workspace/api-zod";
import { authMiddleware, isSupportRole, serializeUser, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

async function enrichChannel(channel: any) {
  const participants = await db.select().from(channelParticipantsTable)
    .where(eq(channelParticipantsTable.channelId, channel.id));

  const users = await Promise.all(participants.map(async (p) => {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, p.userId));
    return user ? serializeUser(user) : null;
  }));

  const [lastMsg] = await db.select().from(messagesTable)
    .where(eq(messagesTable.channelId, channel.id))
    .orderBy(desc(messagesTable.createdAt))
    .limit(1);

  return {
    id: channel.id,
    name: channel.name,
    type: channel.type,
    participants: users.filter(Boolean),
    lastMessage: lastMsg?.content || null,
    lastMessageAt: lastMsg ? (lastMsg.createdAt instanceof Date ? lastMsg.createdAt.toISOString() : lastMsg.createdAt) : null,
    createdAt: channel.createdAt instanceof Date ? channel.createdAt.toISOString() : channel.createdAt,
  };
}

router.get("/channels", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const participations = await db.select().from(channelParticipantsTable)
    .where(eq(channelParticipantsTable.userId, req.user!.id));

  if (participations.length === 0) {
    res.json([]);
    return;
  }

  const channelIds = participations.map(p => p.channelId);
  const channels = await db.select().from(channelsTable)
    .where(inArray(channelsTable.id, channelIds));

  const enriched = await Promise.all(channels.map(enrichChannel));
  res.json(enriched);
});

router.post("/channels", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateChannelBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { participantId } = parsed.data;

  const myParticipations = await db.select().from(channelParticipantsTable)
    .where(eq(channelParticipantsTable.userId, req.user!.id));

  for (const p of myParticipations) {
    const otherParticipants = await db.select().from(channelParticipantsTable)
      .where(and(
        eq(channelParticipantsTable.channelId, p.channelId),
        eq(channelParticipantsTable.userId, participantId)
      ));

    if (otherParticipants.length > 0) {
      const [channel] = await db.select().from(channelsTable).where(eq(channelsTable.id, p.channelId));
      if (channel && channel.type === "dm") {
        const enriched = await enrichChannel(channel);
        res.json(enriched);
        return;
      }
    }
  }

  const [channel] = await db.insert(channelsTable).values({ type: "dm" }).returning();
  await db.insert(channelParticipantsTable).values([
    { channelId: channel.id, userId: req.user!.id },
    { channelId: channel.id, userId: participantId },
  ]);

  const enriched = await enrichChannel(channel);
  res.json(enriched);
});

router.get("/channels/:id/messages", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const messages = await db.select().from(messagesTable)
    .where(eq(messagesTable.channelId, id))
    .orderBy(messagesTable.createdAt);

  const enriched = await Promise.all(messages.map(async (m) => {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, m.userId));
    return {
      id: m.id,
      channelId: m.channelId,
      userId: m.userId,
      content: m.content,
      createdAt: m.createdAt instanceof Date ? m.createdAt.toISOString() : m.createdAt,
      user: user ? serializeUser(user) : null,
    };
  }));

  res.json(enriched);
});

router.post("/channels/:id/messages", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [message] = await db.insert(messagesTable).values({
    channelId: id,
    userId: req.user!.id,
    content: parsed.data.content,
  }).returning();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.user!.id));
  res.status(201).json({
    id: message.id,
    channelId: message.channelId,
    userId: message.userId,
    content: message.content,
    createdAt: message.createdAt instanceof Date ? message.createdAt.toISOString() : message.createdAt,
    user: user ? serializeUser(user) : null,
  });
});

router.get("/support/channels", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!isSupportRole(req.user!.role)) {
    res.status(403).json({ error: "Only support agents can view support channels" });
    return;
  }

  const channels = await db.select().from(channelsTable).where(eq(channelsTable.type, "support"));
  const enriched = await Promise.all(channels.map(enrichChannel));
  res.json(enriched);
});

router.post("/support/channels", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const [channel] = await db.insert(channelsTable).values({
    type: "support",
    name: `Support - ${req.user!.username}`,
  }).returning();

  await db.insert(channelParticipantsTable).values({
    channelId: channel.id,
    userId: req.user!.id,
  });

  const enriched = await enrichChannel(channel);
  res.json(enriched);
});

export default router;
