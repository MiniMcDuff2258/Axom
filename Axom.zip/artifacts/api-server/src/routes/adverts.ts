import { Router, type IRouter } from "express";
import { db, usersTable, advertsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { CreateAdvertBody, UpdateAdvertBody } from "@workspace/api-zod";
import { authMiddleware, type AuthRequest } from "../lib/auth";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/adverts", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (req.user!.role !== "advert" && !["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Only advert role users can manage ads" });
    return;
  }

  const adverts = await db.select().from(advertsTable)
    .where(eq(advertsTable.userId, req.user!.id))
    .orderBy(desc(advertsTable.createdAt));

  res.json(adverts.map(a => ({
    id: a.id,
    userId: a.userId,
    title: a.title,
    content: a.content,
    imageUrl: a.imageUrl,
    linkUrl: a.linkUrl,
    active: a.active,
    createdAt: a.createdAt instanceof Date ? a.createdAt.toISOString() : a.createdAt,
  })));
});

router.post("/adverts", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (req.user!.role !== "advert" && !["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Only advert role users can create ads" });
    return;
  }

  const parsed = CreateAdvertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [advert] = await db.insert(advertsTable).values({
    userId: req.user!.id,
    title: parsed.data.title,
    content: parsed.data.content,
    imageUrl: parsed.data.imageUrl ?? null,
    linkUrl: parsed.data.linkUrl ?? null,
  }).returning();

  res.status(201).json({
    id: advert.id,
    userId: advert.userId,
    title: advert.title,
    content: advert.content,
    imageUrl: advert.imageUrl,
    linkUrl: advert.linkUrl,
    active: advert.active,
    createdAt: advert.createdAt instanceof Date ? advert.createdAt.toISOString() : advert.createdAt,
  });
});

router.get("/adverts/random", async (_req, res): Promise<void> => {
  const [advert] = await db.select().from(advertsTable)
    .where(eq(advertsTable.active, true))
    .orderBy(sql`RANDOM()`)
    .limit(1);

  if (!advert) {
    res.json({ id: 0, userId: 0, title: "", content: "", imageUrl: null, linkUrl: null, active: false, createdAt: "" });
    return;
  }

  res.json({
    id: advert.id,
    userId: advert.userId,
    title: advert.title,
    content: advert.content,
    imageUrl: advert.imageUrl,
    linkUrl: advert.linkUrl,
    active: advert.active,
    createdAt: advert.createdAt instanceof Date ? advert.createdAt.toISOString() : advert.createdAt,
  });
});

router.patch("/adverts/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [advert] = await db.select().from(advertsTable).where(eq(advertsTable.id, id));
  if (!advert) {
    res.status(404).json({ error: "Advert not found" });
    return;
  }

  if (advert.userId !== req.user!.id && !["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const parsed = UpdateAdvertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: any = {};
  if (parsed.data.title != null) updateData.title = parsed.data.title;
  if (parsed.data.content != null) updateData.content = parsed.data.content;
  if (parsed.data.imageUrl != null) updateData.imageUrl = parsed.data.imageUrl;
  if (parsed.data.linkUrl != null) updateData.linkUrl = parsed.data.linkUrl;
  if (parsed.data.active != null) updateData.active = parsed.data.active;

  const [updated] = await db.update(advertsTable).set(updateData).where(eq(advertsTable.id, id)).returning();
  res.json({
    id: updated.id,
    userId: updated.userId,
    title: updated.title,
    content: updated.content,
    imageUrl: updated.imageUrl,
    linkUrl: updated.linkUrl,
    active: updated.active,
    createdAt: updated.createdAt instanceof Date ? updated.createdAt.toISOString() : updated.createdAt,
  });
});

router.delete("/adverts/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [advert] = await db.select().from(advertsTable).where(eq(advertsTable.id, id));
  if (!advert) {
    res.status(404).json({ error: "Advert not found" });
    return;
  }

  if (advert.userId !== req.user!.id && !["admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(advertsTable).where(eq(advertsTable.id, id));
  res.sendStatus(204);
});

export default router;
