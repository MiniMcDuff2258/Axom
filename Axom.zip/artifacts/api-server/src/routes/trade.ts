import { Router, type IRouter } from "express";
import { db, usersTable, tradeListingsTable } from "@workspace/db";
import { eq, desc, ilike } from "drizzle-orm";
import { CreateTradeListingBody, UpdateTradeListingBody } from "@workspace/api-zod";
import { authMiddleware, canCreateTradeListing, serializeUser, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

async function enrichListing(listing: any) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, listing.userId));
  return {
    id: listing.id,
    userId: listing.userId,
    title: listing.title,
    description: listing.description,
    price: listing.price,
    imageUrl: listing.imageUrl,
    category: listing.category,
    status: listing.status,
    createdAt: listing.createdAt instanceof Date ? listing.createdAt.toISOString() : listing.createdAt,
    user: user ? serializeUser(user) : null,
  };
}

router.get("/trade/listings", async (req, res): Promise<void> => {
  const limit = parseInt(req.query.limit as string) || 20;
  const offset = parseInt(req.query.offset as string) || 0;
  const search = req.query.search as string;

  let query = db.select().from(tradeListingsTable);
  if (search) {
    query = query.where(ilike(tradeListingsTable.title, `%${search}%`)) as any;
  }

  const listings = await (query as any).orderBy(desc(tradeListingsTable.createdAt)).limit(limit).offset(offset);
  const enriched = await Promise.all(listings.map(enrichListing));
  res.json(enriched);
});

router.post("/trade/listings", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  if (!canCreateTradeListing(req.user!.role)) {
    res.status(403).json({ error: "Only pro, creator pro, staff, admin, or owner can create listings" });
    return;
  }

  const parsed = CreateTradeListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [listing] = await db.insert(tradeListingsTable).values({
    userId: req.user!.id,
    title: parsed.data.title,
    description: parsed.data.description,
    price: parsed.data.price,
    imageUrl: parsed.data.imageUrl ?? null,
    category: parsed.data.category,
  }).returning();

  const enriched = await enrichListing(listing);
  res.status(201).json(enriched);
});

router.get("/trade/listings/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [listing] = await db.select().from(tradeListingsTable).where(eq(tradeListingsTable.id, id));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  const enriched = await enrichListing(listing);
  res.json(enriched);
});

router.patch("/trade/listings/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [listing] = await db.select().from(tradeListingsTable).where(eq(tradeListingsTable.id, id));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  if (listing.userId !== req.user!.id && !["moderator", "staff", "admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const parsed = UpdateTradeListingBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: any = {};
  if (parsed.data.title) updateData.title = parsed.data.title;
  if (parsed.data.description) updateData.description = parsed.data.description;
  if (parsed.data.price) updateData.price = parsed.data.price;
  if (parsed.data.imageUrl) updateData.imageUrl = parsed.data.imageUrl;
  if (parsed.data.category) updateData.category = parsed.data.category;
  if (parsed.data.status) updateData.status = parsed.data.status;

  const [updated] = await db.update(tradeListingsTable).set(updateData).where(eq(tradeListingsTable.id, id)).returning();
  const enriched = await enrichListing(updated);
  res.json(enriched);
});

router.delete("/trade/listings/:id", authMiddleware as any, async (req: AuthRequest, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  const [listing] = await db.select().from(tradeListingsTable).where(eq(tradeListingsTable.id, id));
  if (!listing) {
    res.status(404).json({ error: "Listing not found" });
    return;
  }

  if (listing.userId !== req.user!.id && !["moderator", "staff", "admin", "owner"].includes(req.user!.role)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(tradeListingsTable).where(eq(tradeListingsTable.id, id));
  res.sendStatus(204);
});

export default router;
