import { Router, type IRouter } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { authMiddleware, type AuthRequest } from "../lib/auth";

const router: IRouter = Router();

const uploadDirs: Record<string, string> = {
  post_image: "uploads/images",
  post_video: "uploads/videos",
  profile_image: "profile_images",
  profile_banner: "profile_banners",
};

for (const dir of Object.values(uploadDirs)) {
  const fullPath = path.resolve(process.cwd(), dir);
  if (!fs.existsSync(fullPath)) {
    fs.mkdirSync(fullPath, { recursive: true });
  }
}

const storage = multer.diskStorage({
  destination: (req: any, _file, cb) => {
    const type = req.body?.type || "post_image";
    const dir = uploadDirs[type] || "uploads/images";
    const fullPath = path.resolve(process.cwd(), dir);
    cb(null, fullPath);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024,
  },
  fileFilter: (_req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp", "video/mp4", "video/webm"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"));
    }
  },
});

router.post("/upload", authMiddleware as any, upload.single("file"), async (req: AuthRequest, res): Promise<void> => {
  if (!req.file) {
    res.status(400).json({ error: "No file uploaded" });
    return;
  }

  const type = req.body?.type || "post_image";
  const dir = uploadDirs[type] || "uploads/images";
  const url = `/api/files/${dir}/${req.file.filename}`;
  res.json({ url });
});

router.get("/files/*filePath", (req, res): void => {
  const raw = Array.isArray(req.params.filePath) ? req.params.filePath[0] : req.params.filePath;
  const filePath = path.resolve(process.cwd(), raw);
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: "File not found" });
  }
});

export default router;
