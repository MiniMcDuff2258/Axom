import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import postsRouter from "./posts";
import messagesRouter from "./messages";
import tradeRouter from "./trade";
import advertsRouter from "./adverts";
import uploadRouter from "./upload";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(postsRouter);
router.use(messagesRouter);
router.use(tradeRouter);
router.use(advertsRouter);
router.use(uploadRouter);

export default router;
