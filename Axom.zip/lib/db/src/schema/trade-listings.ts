import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const tradeListingsTable = pgTable("trade_listings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: text("price").notNull(),
  imageUrl: text("image_url"),
  category: text("category").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTradeListingSchema = createInsertSchema(tradeListingsTable).omit({ id: true, createdAt: true });
export type InsertTradeListing = z.infer<typeof insertTradeListingSchema>;
export type TradeListing = typeof tradeListingsTable.$inferSelect;
