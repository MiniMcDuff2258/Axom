import { pgTable, serial, integer, timestamp, unique } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { channelsTable } from "./channels";

export const channelParticipantsTable = pgTable("channel_participants", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id").notNull().references(() => channelsTable.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  unique("channel_participants_unique").on(table.channelId, table.userId),
]);

export type ChannelParticipant = typeof channelParticipantsTable.$inferSelect;
