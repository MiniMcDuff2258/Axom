import { pgTable, text, serial, integer, timestamp, numeric } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const axisBalancesTable = pgTable("axis_balances", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique().references(() => usersTable.id, { onDelete: "cascade" }),
  balance: numeric("balance", { precision: 18, scale: 4 }).notNull().default("0"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const axisTransactionsTable = pgTable("axis_transactions", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").references(() => usersTable.id),
  toUserId: integer("to_user_id").notNull().references(() => usersTable.id),
  amount: numeric("amount", { precision: 18, scale: 4 }).notNull(),
  type: text("type").notNull(),
  referenceId: integer("reference_id"),
  referenceType: text("reference_type"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AxisBalance = typeof axisBalancesTable.$inferSelect;
export type AxisTransaction = typeof axisTransactionsTable.$inferSelect;
