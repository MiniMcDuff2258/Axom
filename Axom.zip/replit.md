# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + shadcn/ui + Tailwind CSS
- **Auth**: JWT + bcrypt (email/password), tokens stored in localStorage
- **Routing**: wouter (client-side)

## Project: Axom

A full-stack social media platform with dark purple UI theme.

### Features
- Email/password authentication with JWT tokens
- Age-based content restrictions (5+/10+/15+/18+)
- User roles: default, creator, creator_pro, pro, advert, support, moderator, staff, admin, owner
- Posts feed with likes, comments, bookmarks, reports
- Video clips (filtered posts with media_type=video)
- Messaging with support chat channels
- Trade/exchange marketplace (restricted to pro/creator_pro/staff/admin/owner)
- Adverts system
- Profile pages with banner/avatar

### UI
- Dark theme with purple accent (#a855f7)
- "Axom." text logo in purple
- Desktop: sidebar navigation (left)
- Mobile: bottom navigation bar
- DOB picker with year/month/day dropdowns (back to 1900)

### Architecture
- `artifacts/axom/` — React + Vite frontend
- `artifacts/api-server/` — Express API server
- `lib/db/` — Drizzle ORM schema + database connection
- `lib/api-spec/` — OpenAPI spec
- `lib/api-client-react/` — Generated React hooks (Orval)
- `lib/api-zod/` — Generated Zod schemas

### Auth Flow
- Login/Signup returns `{ user, token }`
- Token stored in localStorage (`axom_token`)
- `setAuthTokenGetter` attaches Bearer token to all API requests
- `useAuth()` context provides `{ user, isLoading, login, logout, refetch }`
- Protected routes redirect to `/login` if no user

### Test Accounts
- admin@axom.io / password123 (owner role)
- alex@axom.io / password123 (creator role)
- jordan@axom.io / password123 (pro role)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
